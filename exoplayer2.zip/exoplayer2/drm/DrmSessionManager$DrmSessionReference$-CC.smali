.class public final synthetic Lcom/google/android/exoplayer2/drm/DrmSessionManager$DrmSessionReference$-CC;
.super Ljava/lang/Object;
.source "DrmSessionManager.java"


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    sget-object v0, Lcom/google/android/exoplayer2/drm/DrmSessionManager$DrmSessionReference;->EMPTY:Lcom/google/android/exoplayer2/drm/DrmSessionManager$DrmSessionReference;

    return-void
.end method

.method public static synthetic lambda$static$0()V
    .registers 0

    return-void
.end method
