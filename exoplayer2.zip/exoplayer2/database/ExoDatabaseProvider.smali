.class public final Lcom/google/android/exoplayer2/database/ExoDatabaseProvider;
.super Lcom/google/android/exoplayer2/database/StandaloneDatabaseProvider;
.source "ExoDatabaseProvider.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/google/android/exoplayer2/database/StandaloneDatabaseProvider;-><init>(Landroid/content/Context;)V

    return-void
.end method
