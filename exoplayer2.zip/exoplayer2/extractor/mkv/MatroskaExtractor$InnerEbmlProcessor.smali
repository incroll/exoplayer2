.class final Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;
.super Ljava/lang/Object;
.source "MatroskaExtractor.java"

# interfaces
.implements Lcom/google/android/exoplayer2/extractor/mkv/EbmlProcessor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "InnerEbmlProcessor"
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;


# direct methods
.method private constructor <init>(Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$1;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;-><init>(Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;)V

    return-void
.end method


# virtual methods
.method public binaryElement(IILcom/google/android/exoplayer2/extractor/ExtractorInput;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;->binaryElement(IILcom/google/android/exoplayer2/extractor/ExtractorInput;)V

    return-void
.end method

.method public endMasterElement(I)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/exoplayer2/ParserException;
        }
    .end annotation

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-virtual {v0, p1}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;->endMasterElement(I)V

    return-void
.end method

.method public floatElement(ID)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/exoplayer2/ParserException;
        }
    .end annotation

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;->floatElement(ID)V

    return-void
.end method

.method public getElementType(I)I
    .registers 3

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    sparse-switch p1, :sswitch_data_14

    const/4 p1, 0x0

    goto :goto_13

    :sswitch_a
    const/4 p1, 0x5

    goto :goto_13

    :sswitch_c
    const/4 p1, 0x4

    goto :goto_13

    :sswitch_e
    const/4 p1, 0x1

    goto :goto_13

    :sswitch_10
    const/4 p1, 0x3

    goto :goto_13

    :sswitch_12
    const/4 p1, 0x2

    :goto_13
    return p1

    :sswitch_data_14
    .sparse-switch
        0x83 -> :sswitch_12
        0x86 -> :sswitch_10
        0x88 -> :sswitch_12
        0x9b -> :sswitch_12
        0x9f -> :sswitch_12
        0xa0 -> :sswitch_e
        0xa1 -> :sswitch_c
        0xa3 -> :sswitch_c
        0xa5 -> :sswitch_c
        0xa6 -> :sswitch_e
        0xae -> :sswitch_e
        0xb0 -> :sswitch_12
        0xb3 -> :sswitch_12
        0xb5 -> :sswitch_a
        0xb7 -> :sswitch_e
        0xba -> :sswitch_12
        0xbb -> :sswitch_e
        0xd7 -> :sswitch_12
        0xe0 -> :sswitch_e
        0xe1 -> :sswitch_e
        0xe7 -> :sswitch_12
        0xee -> :sswitch_12
        0xf1 -> :sswitch_12
        0xfb -> :sswitch_12
        0x41e4 -> :sswitch_e
        0x41e7 -> :sswitch_12
        0x41ed -> :sswitch_c
        0x4254 -> :sswitch_12
        0x4255 -> :sswitch_c
        0x4282 -> :sswitch_10
        0x4285 -> :sswitch_12
        0x42f7 -> :sswitch_12
        0x4489 -> :sswitch_a
        0x47e1 -> :sswitch_12
        0x47e2 -> :sswitch_c
        0x47e7 -> :sswitch_e
        0x47e8 -> :sswitch_12
        0x4dbb -> :sswitch_e
        0x5031 -> :sswitch_12
        0x5032 -> :sswitch_12
        0x5034 -> :sswitch_e
        0x5035 -> :sswitch_e
        0x536e -> :sswitch_10
        0x53ab -> :sswitch_c
        0x53ac -> :sswitch_12
        0x53b8 -> :sswitch_12
        0x54b0 -> :sswitch_12
        0x54b2 -> :sswitch_12
        0x54ba -> :sswitch_12
        0x55aa -> :sswitch_12
        0x55b0 -> :sswitch_e
        0x55b9 -> :sswitch_12
        0x55ba -> :sswitch_12
        0x55bb -> :sswitch_12
        0x55bc -> :sswitch_12
        0x55bd -> :sswitch_12
        0x55d0 -> :sswitch_e
        0x55d1 -> :sswitch_a
        0x55d2 -> :sswitch_a
        0x55d3 -> :sswitch_a
        0x55d4 -> :sswitch_a
        0x55d5 -> :sswitch_a
        0x55d6 -> :sswitch_a
        0x55d7 -> :sswitch_a
        0x55d8 -> :sswitch_a
        0x55d9 -> :sswitch_a
        0x55da -> :sswitch_a
        0x55ee -> :sswitch_12
        0x56aa -> :sswitch_12
        0x56bb -> :sswitch_12
        0x6240 -> :sswitch_e
        0x6264 -> :sswitch_12
        0x63a2 -> :sswitch_c
        0x6d80 -> :sswitch_e
        0x75a1 -> :sswitch_e
        0x75a2 -> :sswitch_12
        0x7670 -> :sswitch_e
        0x7671 -> :sswitch_12
        0x7672 -> :sswitch_c
        0x7673 -> :sswitch_a
        0x7674 -> :sswitch_a
        0x7675 -> :sswitch_a
        0x22b59c -> :sswitch_10
        0x23e383 -> :sswitch_12
        0x2ad7b1 -> :sswitch_12
        0x114d9b74 -> :sswitch_e
        0x1549a966 -> :sswitch_e
        0x1654ae6b -> :sswitch_e
        0x18538067 -> :sswitch_e
        0x1a45dfa3 -> :sswitch_e
        0x1c53bb6b -> :sswitch_e
        0x1f43b675 -> :sswitch_e
    .end sparse-switch
.end method

.method public integerElement(IJ)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/exoplayer2/ParserException;
        }
    .end annotation

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;->integerElement(IJ)V

    return-void
.end method

.method public isLevel1Element(I)Z
    .registers 3

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const v0, 0x1549a966

    if-eq p1, v0, :cond_1c

    const v0, 0x1f43b675

    if-eq p1, v0, :cond_1c

    const v0, 0x1c53bb6b

    if-eq p1, v0, :cond_1c

    const v0, 0x1654ae6b

    if-ne p1, v0, :cond_1a

    goto :goto_1c

    :cond_1a
    const/4 p1, 0x0

    goto :goto_1d

    :cond_1c
    :goto_1c
    const/4 p1, 0x1

    :goto_1d
    return p1
.end method

.method public startMasterElement(IJJ)V
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/exoplayer2/ParserException;
        }
    .end annotation

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    move v1, p1

    move-wide v2, p2

    move-wide v4, p4

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;->startMasterElement(IJJ)V

    return-void
.end method

.method public stringElement(ILjava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/exoplayer2/ParserException;
        }
    .end annotation

    iget-object v0, p0, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor$InnerEbmlProcessor;->this$0:Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;

    invoke-virtual {v0, p1, p2}, Lcom/google/android/exoplayer2/extractor/mkv/MatroskaExtractor;->stringElement(ILjava/lang/String;)V

    return-void
.end method
