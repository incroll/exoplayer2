.class Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;
.super Ljava/lang/Object;
.source "CronetUtil.java"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/ext/cronet/CronetUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "CronetProviderComparator"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lorg/chromium/net/CronetProvider;",
        ">;"
    }
.end annotation


# static fields
.field private static final GOOGLE_PLAY_SERVICES_PROVIDER_NAME:Ljava/lang/String; = "Google-Play-Services-Cronet-Provider"


# instance fields
.field private final preferGooglePlayServices:Z


# direct methods
.method public constructor <init>(Z)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-boolean p1, p0, Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;->preferGooglePlayServices:Z

    return-void
.end method

.method private static compareVersionStrings(Ljava/lang/String;Ljava/lang/String;)I
    .registers 7
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    const/4 v0, 0x0

    if-eqz p0, :cond_35

    if-nez p1, :cond_6

    goto :goto_35

    :cond_6
    const-string v1, "\\."

    .line 1
    invoke-static {p0, v1}, Lcom/google/android/exoplayer2/util/Util;->split(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-static {p1, v1}, Lcom/google/android/exoplayer2/util/Util;->split(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 3
    array-length v1, p0

    array-length v2, p1

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x0

    :goto_17
    if-ge v2, v1, :cond_35

    .line 4
    aget-object v3, p0, v2

    aget-object v4, p1, v2

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_32

    .line 5
    :try_start_23
    aget-object p0, p0, v2

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    .line 6
    aget-object p1, p1, v2

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1
    :try_end_2f
    .catch Ljava/lang/NumberFormatException; {:try_start_23 .. :try_end_2f} :catch_31

    sub-int/2addr p0, p1

    return p0

    :catch_31
    return v0

    :cond_32
    add-int/lit8 v2, v2, 0x1

    goto :goto_17

    :cond_35
    :goto_35
    return v0
.end method

.method private getPriority(Lorg/chromium/net/CronetProvider;)I
    .registers 3

    .line 1
    invoke-virtual {p1}, Lorg/chromium/net/CronetProvider;->getName()Ljava/lang/String;

    move-result-object p1

    const-string v0, "App-Packaged-Cronet-Provider"

    .line 2
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    const/4 p1, 0x1

    return p1

    :cond_e
    const-string v0, "Google-Play-Services-Cronet-Provider"

    .line 3
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1e

    .line 4
    iget-boolean p1, p0, Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;->preferGooglePlayServices:Z

    if-eqz p1, :cond_1c

    const/4 p1, 0x0

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x2

    :goto_1d
    return p1

    :cond_1e
    const/4 p1, 0x3

    return p1
.end method


# virtual methods
.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 3

    .line 1
    check-cast p1, Lorg/chromium/net/CronetProvider;

    check-cast p2, Lorg/chromium/net/CronetProvider;

    invoke-virtual {p0, p1, p2}, Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;->compare(Lorg/chromium/net/CronetProvider;Lorg/chromium/net/CronetProvider;)I

    move-result p1

    return p1
.end method

.method public compare(Lorg/chromium/net/CronetProvider;Lorg/chromium/net/CronetProvider;)I
    .registers 5

    .line 2
    invoke-direct {p0, p1}, Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;->getPriority(Lorg/chromium/net/CronetProvider;)I

    move-result v0

    invoke-direct {p0, p2}, Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;->getPriority(Lorg/chromium/net/CronetProvider;)I

    move-result v1

    sub-int/2addr v0, v1

    if-eqz v0, :cond_c

    return v0

    .line 3
    :cond_c
    invoke-virtual {p1}, Lorg/chromium/net/CronetProvider;->getVersion()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Lorg/chromium/net/CronetProvider;->getVersion()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/google/android/exoplayer2/ext/cronet/CronetUtil$CronetProviderComparator;->compareVersionStrings(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    neg-int p1, p1

    return p1
.end method
