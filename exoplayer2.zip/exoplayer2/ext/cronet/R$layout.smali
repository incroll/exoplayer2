.class public final Lcom/google/android/exoplayer2/ext/cronet/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/ext/cronet/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final custom_dialog:I = 0x7f0e0037

.field public static final notification_action:I = 0x7f0e00f4

.field public static final notification_action_tombstone:I = 0x7f0e00f5

.field public static final notification_template_custom_big:I = 0x7f0e00fc

.field public static final notification_template_icon_group:I = 0x7f0e00fd

.field public static final notification_template_part_chronometer:I = 0x7f0e0101

.field public static final notification_template_part_time:I = 0x7f0e0102


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
