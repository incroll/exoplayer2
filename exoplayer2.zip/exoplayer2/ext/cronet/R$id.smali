.class public final Lcom/google/android/exoplayer2/ext/cronet/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/ext/cronet/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final accessibility_action_clickable_span:I = 0x7f0b0014

.field public static final accessibility_custom_action_0:I = 0x7f0b0015

.field public static final accessibility_custom_action_1:I = 0x7f0b0016

.field public static final accessibility_custom_action_10:I = 0x7f0b0017

.field public static final accessibility_custom_action_11:I = 0x7f0b0018

.field public static final accessibility_custom_action_12:I = 0x7f0b0019

.field public static final accessibility_custom_action_13:I = 0x7f0b001a

.field public static final accessibility_custom_action_14:I = 0x7f0b001b

.field public static final accessibility_custom_action_15:I = 0x7f0b001c

.field public static final accessibility_custom_action_16:I = 0x7f0b001d

.field public static final accessibility_custom_action_17:I = 0x7f0b001e

.field public static final accessibility_custom_action_18:I = 0x7f0b001f

.field public static final accessibility_custom_action_19:I = 0x7f0b0020

.field public static final accessibility_custom_action_2:I = 0x7f0b0021

.field public static final accessibility_custom_action_20:I = 0x7f0b0022

.field public static final accessibility_custom_action_21:I = 0x7f0b0023

.field public static final accessibility_custom_action_22:I = 0x7f0b0024

.field public static final accessibility_custom_action_23:I = 0x7f0b0025

.field public static final accessibility_custom_action_24:I = 0x7f0b0026

.field public static final accessibility_custom_action_25:I = 0x7f0b0027

.field public static final accessibility_custom_action_26:I = 0x7f0b0028

.field public static final accessibility_custom_action_27:I = 0x7f0b0029

.field public static final accessibility_custom_action_28:I = 0x7f0b002a

.field public static final accessibility_custom_action_29:I = 0x7f0b002b

.field public static final accessibility_custom_action_3:I = 0x7f0b002c

.field public static final accessibility_custom_action_30:I = 0x7f0b002d

.field public static final accessibility_custom_action_31:I = 0x7f0b002e

.field public static final accessibility_custom_action_4:I = 0x7f0b002f

.field public static final accessibility_custom_action_5:I = 0x7f0b0030

.field public static final accessibility_custom_action_6:I = 0x7f0b0031

.field public static final accessibility_custom_action_7:I = 0x7f0b0032

.field public static final accessibility_custom_action_8:I = 0x7f0b0033

.field public static final accessibility_custom_action_9:I = 0x7f0b0034

.field public static final action_container:I = 0x7f0b0041

.field public static final action_divider:I = 0x7f0b0043

.field public static final action_image:I = 0x7f0b0047

.field public static final action_text:I = 0x7f0b004d

.field public static final actions:I = 0x7f0b004e

.field public static final adjust_height:I = 0x7f0b0052

.field public static final adjust_width:I = 0x7f0b0053

.field public static final async:I = 0x7f0b005f

.field public static final auto:I = 0x7f0b0060

.field public static final blocking:I = 0x7f0b0071

.field public static final bottom:I = 0x7f0b0073

.field public static final chronometer:I = 0x7f0b00bf

.field public static final dark:I = 0x7f0b00e4

.field public static final dialog_button:I = 0x7f0b0100

.field public static final end:I = 0x7f0b011f

.field public static final forever:I = 0x7f0b0178

.field public static final icon:I = 0x7f0b01ba

.field public static final icon_group:I = 0x7f0b01bb

.field public static final icon_only:I = 0x7f0b01bc

.field public static final info:I = 0x7f0b01f5

.field public static final italic:I = 0x7f0b01fd

.field public static final left:I = 0x7f0b0224

.field public static final light:I = 0x7f0b0227

.field public static final line1:I = 0x7f0b0228

.field public static final line3:I = 0x7f0b0229

.field public static final none:I = 0x7f0b02b9

.field public static final normal:I = 0x7f0b02ba

.field public static final notification_background:I = 0x7f0b02be

.field public static final notification_main_column:I = 0x7f0b02bf

.field public static final notification_main_column_container:I = 0x7f0b02c0

.field public static final right:I = 0x7f0b02f8

.field public static final right_icon:I = 0x7f0b02fa

.field public static final right_side:I = 0x7f0b02fb

.field public static final standard:I = 0x7f0b034b

.field public static final start:I = 0x7f0b034c

.field public static final tag_accessibility_actions:I = 0x7f0b0381

.field public static final tag_accessibility_clickable_spans:I = 0x7f0b0382

.field public static final tag_accessibility_heading:I = 0x7f0b0383

.field public static final tag_accessibility_pane_title:I = 0x7f0b0384

.field public static final tag_screen_reader_focusable:I = 0x7f0b0388

.field public static final tag_transition_group:I = 0x7f0b038a

.field public static final tag_unhandled_key_event_manager:I = 0x7f0b038b

.field public static final tag_unhandled_key_listeners:I = 0x7f0b038c

.field public static final text:I = 0x7f0b038e

.field public static final text2:I = 0x7f0b038f

.field public static final time:I = 0x7f0b03a0

.field public static final title:I = 0x7f0b03a1

.field public static final top:I = 0x7f0b03a8

.field public static final wide:I = 0x7f0b0426


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
