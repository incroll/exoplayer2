.class public final Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;
.super Ljava/lang/Object;
.source "FfmpegLibrary.java"


# static fields
.field private static final LOADER:Lcom/google/android/exoplayer2/util/LibraryLoader;

.field private static final TAG:Ljava/lang/String; = "FfmpegLibrary"

.field private static inputBufferPaddingSize:I

.field private static version:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    const-string v0, "goog.exo.ffmpeg"

    .line 1
    invoke-static {v0}, Lcom/google/android/exoplayer2/ExoPlayerLibraryInfo;->registerModule(Ljava/lang/String;)V

    .line 2
    new-instance v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary$1;

    const-string v1, "ffmpegJNI"

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary$1;-><init>([Ljava/lang/String;)V

    sput-object v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->LOADER:Lcom/google/android/exoplayer2/util/LibraryLoader;

    const/4 v0, -0x1

    .line 3
    sput v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->inputBufferPaddingSize:I

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static native ffmpegGetInputBufferPaddingSize()I
.end method

.method private static native ffmpegGetVersion()Ljava/lang/String;
.end method

.method private static native ffmpegHasDecoder(Ljava/lang/String;)Z
.end method

.method public static getCodecName(Ljava/lang/String;)Ljava/lang/String;
    .registers 3
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, -0x1

    sparse-switch v0, :sswitch_data_122

    goto/16 :goto_f0

    :sswitch_d
    const-string v0, "audio/g711-mlaw"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_17

    goto/16 :goto_f0

    :cond_17
    const/16 v1, 0x11

    goto/16 :goto_f0

    :sswitch_1b
    const-string v0, "audio/g711-alaw"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_25

    goto/16 :goto_f0

    :cond_25
    const/16 v1, 0x10

    goto/16 :goto_f0

    :sswitch_29
    const-string v0, "audio/true-hd"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_33

    goto/16 :goto_f0

    :cond_33
    const/16 v1, 0xf

    goto/16 :goto_f0

    :sswitch_37
    const-string v0, "audio/vnd.dts.hd"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_41

    goto/16 :goto_f0

    :cond_41
    const/16 v1, 0xe

    goto/16 :goto_f0

    :sswitch_45
    const-string v0, "audio/opus"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4f

    goto/16 :goto_f0

    :cond_4f
    const/16 v1, 0xd

    goto/16 :goto_f0

    :sswitch_53
    const-string v0, "audio/mpeg"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5d

    goto/16 :goto_f0

    :cond_5d
    const/16 v1, 0xc

    goto/16 :goto_f0

    :sswitch_61
    const-string v0, "audio/flac"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_6b

    goto/16 :goto_f0

    :cond_6b
    const/16 v1, 0xb

    goto/16 :goto_f0

    :sswitch_6f
    const-string v0, "audio/eac3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_79

    goto/16 :goto_f0

    :cond_79
    const/16 v1, 0xa

    goto/16 :goto_f0

    :sswitch_7d
    const-string v0, "audio/alac"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_87

    goto/16 :goto_f0

    :cond_87
    const/16 v1, 0x9

    goto/16 :goto_f0

    :sswitch_8b
    const-string v0, "audio/3gpp"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_95

    goto/16 :goto_f0

    :cond_95
    const/16 v1, 0x8

    goto/16 :goto_f0

    :sswitch_99
    const-string v0, "audio/ac3"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_a2

    goto :goto_f0

    :cond_a2
    const/4 v1, 0x7

    goto :goto_f0

    :sswitch_a4
    const-string v0, "audio/mp4a-latm"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_ad

    goto :goto_f0

    :cond_ad
    const/4 v1, 0x6

    goto :goto_f0

    :sswitch_af
    const-string v0, "audio/mpeg-L2"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_b8

    goto :goto_f0

    :cond_b8
    const/4 v1, 0x5

    goto :goto_f0

    :sswitch_ba
    const-string v0, "audio/mpeg-L1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_c3

    goto :goto_f0

    :cond_c3
    const/4 v1, 0x4

    goto :goto_f0

    :sswitch_c5
    const-string v0, "audio/vorbis"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_ce

    goto :goto_f0

    :cond_ce
    const/4 v1, 0x3

    goto :goto_f0

    :sswitch_d0
    const-string v0, "audio/vnd.dts"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_d9

    goto :goto_f0

    :cond_d9
    const/4 v1, 0x2

    goto :goto_f0

    :sswitch_db
    const-string v0, "audio/amr-wb"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_e4

    goto :goto_f0

    :cond_e4
    const/4 v1, 0x1

    goto :goto_f0

    :sswitch_e6
    const-string v0, "audio/eac3-joc"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_ef

    goto :goto_f0

    :cond_ef
    const/4 v1, 0x0

    :goto_f0
    packed-switch v1, :pswitch_data_16c

    const/4 p0, 0x0

    return-object p0

    :pswitch_f5
    const-string p0, "pcm_mulaw"

    return-object p0

    :pswitch_f8
    const-string p0, "pcm_alaw"

    return-object p0

    :pswitch_fb
    const-string/jumbo p0, "truehd"

    return-object p0

    :pswitch_ff
    const-string p0, "opus"

    return-object p0

    :pswitch_102
    const-string p0, "flac"

    return-object p0

    :pswitch_105
    const-string p0, "alac"

    return-object p0

    :pswitch_108
    const-string p0, "amrnb"

    return-object p0

    :pswitch_10b
    const-string p0, "ac3"

    return-object p0

    :pswitch_10e
    const-string p0, "aac"

    return-object p0

    :pswitch_111
    const-string p0, "mp3"

    return-object p0

    :pswitch_114
    const-string/jumbo p0, "vorbis"

    return-object p0

    :pswitch_118
    const-string p0, "dca"

    return-object p0

    :pswitch_11b
    const-string p0, "amrwb"

    return-object p0

    :pswitch_11e
    const-string p0, "eac3"

    return-object p0

    nop

    :sswitch_data_122
    .sparse-switch
        -0x7e929daa -> :sswitch_e6
        -0x5fc6f775 -> :sswitch_db
        -0x41455b98 -> :sswitch_d0
        -0x3bd43e14 -> :sswitch_c5
        -0x19cc928c -> :sswitch_ba
        -0x19cc928b -> :sswitch_af
        -0x3313c2e -> :sswitch_a4
        0xb269698 -> :sswitch_99
        0x59976a2d -> :sswitch_8b
        0x59ac6426 -> :sswitch_7d
        0x59ae0c65 -> :sswitch_6f
        0x59aeaa01 -> :sswitch_61
        0x59b1e81e -> :sswitch_53
        0x59b2d2d8 -> :sswitch_45
        0x59c2dc42 -> :sswitch_37
        0x5cc95062 -> :sswitch_29
        0x71710385 -> :sswitch_1b
        0x717677f9 -> :sswitch_d
    .end sparse-switch

    :pswitch_data_16c
    .packed-switch 0x0
        :pswitch_11e
        :pswitch_11b
        :pswitch_118
        :pswitch_114
        :pswitch_111
        :pswitch_111
        :pswitch_10e
        :pswitch_10b
        :pswitch_108
        :pswitch_105
        :pswitch_11e
        :pswitch_102
        :pswitch_111
        :pswitch_ff
        :pswitch_118
        :pswitch_fb
        :pswitch_f8
        :pswitch_f5
    .end packed-switch
.end method

.method public static getInputBufferPaddingSize()I
    .registers 2

    .line 1
    invoke-static {}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->isAvailable()Z

    move-result v0

    const/4 v1, -0x1

    if-nez v0, :cond_8

    return v1

    .line 2
    :cond_8
    sget v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->inputBufferPaddingSize:I

    if-ne v0, v1, :cond_12

    .line 3
    invoke-static {}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->ffmpegGetInputBufferPaddingSize()I

    move-result v0

    sput v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->inputBufferPaddingSize:I

    .line 4
    :cond_12
    sget v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->inputBufferPaddingSize:I

    return v0
.end method

.method public static getVersion()Ljava/lang/String;
    .registers 1
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .line 1
    invoke-static {}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->isAvailable()Z

    move-result v0

    if-nez v0, :cond_8

    const/4 v0, 0x0

    return-object v0

    .line 2
    :cond_8
    sget-object v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->version:Ljava/lang/String;

    if-nez v0, :cond_12

    .line 3
    invoke-static {}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->ffmpegGetVersion()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->version:Ljava/lang/String;

    .line 4
    :cond_12
    sget-object v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->version:Ljava/lang/String;

    return-object v0
.end method

.method public static isAvailable()Z
    .registers 1

    sget-object v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->LOADER:Lcom/google/android/exoplayer2/util/LibraryLoader;

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/util/LibraryLoader;->isAvailable()Z

    move-result v0

    return v0
.end method

.method public static varargs setLibraries([Ljava/lang/String;)V
    .registers 2

    sget-object v0, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->LOADER:Lcom/google/android/exoplayer2/util/LibraryLoader;

    invoke-virtual {v0, p0}, Lcom/google/android/exoplayer2/util/LibraryLoader;->setLibraries([Ljava/lang/String;)V

    return-void
.end method

.method public static supportsFormat(Ljava/lang/String;)Z
    .registers 4

    .line 1
    invoke-static {}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->isAvailable()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    .line 2
    :cond_8
    invoke-static {p0}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->getCodecName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_f

    return v1

    .line 3
    :cond_f
    invoke-static {p0}, Lcom/google/android/exoplayer2/ext/ffmpeg/FfmpegLibrary;->ffmpegHasDecoder(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_31

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "No "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " decoder available. Check the FFmpeg build configuration."

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "FfmpegLibrary"

    invoke-static {v0, p0}, Lcom/google/android/exoplayer2/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)V

    return v1

    :cond_31
    const/4 p0, 0x1

    return p0
.end method
